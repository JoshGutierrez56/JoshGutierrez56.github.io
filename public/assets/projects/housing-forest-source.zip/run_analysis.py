#!/usr/bin/env python3
"""Walk-forward Case-Shiller random-forest evaluation with a naive baseline."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

TARGET_RAW = "S&P CoreLogic Case-Shiller 20-City Composite Home Price Index"
TARGET = "CaseShillerIndex"
LAGS = (1, 3, 6, 12)
ECONOMIC_FEATURES = [
    "Consumer Price Index for All Urban Consumers: All Items Less Food and Energy in U.S. City Average",
    "Producer Price Index by Commodity: Intermediate Demand by Commodity Type: Processed Goods for Intermediate Demand",
    "New Privately-Owned Housing Units Started: Total Units",
    "New Privately-Owned Housing Units Authorized in Permit-Issuing Places: Total Units",
    "Total Population: All Ages including Armed Forces Overseas",
    "Unemployment Rate",
    "Average Hourly Earnings of Production and Nonsupervisory Employees, Total Private",
    "Real Gross Domestic Product",
    "Real personal income excluding current transfer receipts",
    "Personal Saving Rate",
]


def prepare_data(path: Path) -> tuple[pd.DataFrame, list[str]]:
    frame = pd.read_excel(path)
    required = {"Date", TARGET_RAW, *ECONOMIC_FEATURES}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    frame["Date"] = pd.to_datetime(frame["Date"])
    frame = frame.sort_values("Date").drop_duplicates("Date", keep="last")
    frame = frame.rename(columns={TARGET_RAW: TARGET})
    for lag in LAGS:
        frame[f"Lag_{lag}"] = frame[TARGET].shift(lag)
    features = ECONOMIC_FEATURES + [f"Lag_{lag}" for lag in LAGS]
    frame = frame.dropna(subset=[TARGET, *features]).reset_index(drop=True)
    return frame, features


def walk_forward(
    frame: pd.DataFrame,
    features: list[str],
    start_date: pd.Timestamp,
    n_estimators: int,
    seed: int,
) -> pd.DataFrame:
    rows = []
    for current_date in frame.loc[frame["Date"] >= start_date, "Date"]:
        train = frame[frame["Date"] < current_date]
        test = frame[frame["Date"] == current_date]
        if train.empty or test.empty:
            continue
        model = RandomForestRegressor(
            n_estimators=n_estimators,
            random_state=seed,
            n_jobs=-1,
        )
        model.fit(train[features], train[TARGET])
        rows.append(
            {
                "Date": current_date,
                "actual": float(test[TARGET].iloc[0]),
                "random_forest": float(model.predict(test[features])[0]),
                "naive_lag1": float(test["Lag_1"].iloc[0]),
            }
        )
    if not rows:
        raise ValueError("No walk-forward observations were produced.")
    return pd.DataFrame(rows)


def run(args: argparse.Namespace) -> dict[str, float | int | str]:
    frame, features = prepare_data(Path(args.input))
    predictions = walk_forward(
        frame,
        features,
        pd.Timestamp(args.test_start),
        args.n_estimators,
        args.seed,
    )
    actual = predictions["actual"]
    rf = predictions["random_forest"]
    naive = predictions["naive_lag1"]
    metrics: dict[str, float | int | str] = {
        "status": "complete",
        "test_start": str(predictions["Date"].min().date()),
        "test_end": str(predictions["Date"].max().date()),
        "observations": len(predictions),
        "n_estimators": args.n_estimators,
        "seed": args.seed,
        "random_forest_rmse": float(np.sqrt(mean_squared_error(actual, rf))),
        "random_forest_mae": float(mean_absolute_error(actual, rf)),
        "random_forest_r2": float(r2_score(actual, rf)),
        "naive_lag1_rmse": float(np.sqrt(mean_squared_error(actual, naive))),
    }
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(output / "walk_forward_predictions.csv", index=False)
    (output / "metrics.json").write_text(
        json.dumps(metrics, indent=2) + "\n", encoding="utf-8"
    )

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(predictions["Date"], actual, label="Actual", linewidth=2)
    ax.plot(
        predictions["Date"],
        rf,
        label="Random forest",
        linestyle="--",
        linewidth=1.8,
    )
    ax.plot(
        predictions["Date"],
        naive,
        label="Naive lag-1",
        linestyle=":",
        linewidth=1.5,
    )
    ax.set_title(
        f"Case-Shiller Walk-Forward — RF RMSE {metrics['random_forest_rmse']:.2f}; "
        f"lag-1 RMSE {metrics['naive_lag1_rmse']:.2f}"
    )
    ax.set_xlabel("Date")
    ax.set_ylabel("Case-Shiller Index")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(output / "walk_forward_evaluation.png", dpi=150)
    plt.close(fig)
    print(json.dumps(metrics, indent=2))
    print(f"Results written to {output.resolve()}")
    return metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="case_shiller_data.xlsx")
    parser.add_argument("--output-dir", default="results")
    parser.add_argument("--test-start", default="2020-01-01")
    parser.add_argument("--n-estimators", type=int, default=100)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
