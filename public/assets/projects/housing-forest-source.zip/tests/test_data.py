from __future__ import annotations

from pathlib import Path

from run_analysis import prepare_data


def test_data_is_chronological_and_lagged() -> None:
    root = Path(__file__).resolve().parents[1]
    frame, features = prepare_data(root / "case_shiller_data.xlsx")
    assert frame["Date"].is_monotonic_increasing
    assert "Lag_12" in features
    assert frame[features].notna().all().all()
