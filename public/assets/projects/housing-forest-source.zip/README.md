# Archived Case-Shiller evaluation source

This archive preserves the evaluated July 20, 2026 research revision, not the current original-notebook repository HEAD. It contains the evaluation code, its tests, dependency requirements, and frozen outputs.

To reproduce, download case_shiller_data.xlsx from the original public repository at commit 6cc3ee3c3df5227280338a00dbae8b00c2e19f19, place it beside run_analysis.py, install requirements.txt, then run:

python run_analysis.py
python -m pytest -q

Dataset: https://github.com/JoshGutierrez56/CaseShillerRandomForest/blob/6cc3ee3c3df5227280338a00dbae8b00c2e19f19/case_shiller_data.xlsx

The source workbook is a bundled historical Case-Shiller and macroeconomic panel. Its original download process and data vintage are not verified. It is not included in this archive. Results are not a release-date-aware real-time forecast. Dependencies use minimum versions, so exact byte-for-byte reproducibility across environments is not guaranteed.

Archived code revision: 3cbb4e50f076b2056e104d22f2bc3cbc5527715d
The code uses scikit-learn RandomForestRegressor; this is applied model/evaluation work, not a new random-forest algorithm.
