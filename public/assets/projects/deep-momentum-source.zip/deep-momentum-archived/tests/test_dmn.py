from pathlib import Path

import numpy as np

from benchmark import plot_fold_results
from dmn import compute_features, prepare_sequences, synthetic_data


def test_synthetic_data_is_deterministic_and_positive():
    first = synthetic_data("2019-01-01", "2021-12-31", seed=7)
    second = synthetic_data("2019-01-01", "2021-12-31", seed=7)

    assert first.equals(second)
    assert (first[["open", "high", "low", "close"]] > 0).all().all()


def test_sequence_metadata_uses_realized_return_date():
    raw = synthetic_data("2018-01-01", "2021-12-31", seed=11)
    featured, columns = compute_features(raw)
    sequences, labels, metadata = prepare_sequences(
        featured, columns, "equity", seq_length=21
    )

    assert len(sequences) == len(labels) == len(metadata)
    date, ticker, _ = metadata[0]
    realized = featured.xs(ticker, level="ticker")["return"].loc[date]
    assert np.isclose(labels[0, 0], realized)


def test_benchmark_requires_recorded_metrics(tmp_path: Path):
    missing = tmp_path / "missing.csv"
    try:
        plot_fold_results(str(missing), str(tmp_path / "plot.png"))
    except FileNotFoundError as exc:
        assert "Run `python dmn.py --offline --quick`" in str(exc)
    else:
        raise AssertionError("missing metrics should not be replaced by hard-coded values")
