"""
Deep Momentum Network - PyTorch Implementation
Based on Lim, Zohren & Roberts (2019)

Key methodology:
1. Volatility-scaled features (not sequence normalization)
2. Separate model per asset class
3. Sequence-level Sharpe loss
4. Vol scaling after network output
5. Walk-forward validation
"""

import argparse
import json
from pathlib import Path
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore')

import yfinance as yf
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# =============================================================================
# CONFIGURATION
# =============================================================================

ASSET_CLASSES = {
    'equity': {'SPY': 'S&P 500', 'QQQ': 'Nasdaq 100', 'IWM': 'Russell 2000', 
               'DIA': 'Dow Jones', 'EFA': 'Developed Markets', 'EEM': 'Emerging Markets',
               'FXI': 'China', 'EWJ': 'Japan', 'VNQ': 'REITs'},
    'bonds': {'TLT': '20+ Year Treasury', 'IEF': '7-10 Year Treasury', 
              'SHY': '1-3 Year Treasury', 'LQD': 'Investment Grade', 'HYG': 'High Yield'},
    'commodities': {'GLD': 'Gold', 'SLV': 'Silver', 'USO': 'Oil', 
                    'UNG': 'Natural Gas', 'DBA': 'Agriculture'},
    'currencies': {'UUP': 'US Dollar', 'FXE': 'Euro', 'FXY': 'Yen', 'FXB': 'British Pound'},
}

CONFIG = {
    'start_date': '2006-01-01',
    'end_date': '2024-12-31',
    'sequence_length': 63,
    'hidden_size': 32,
    'dropout': 0.3,
    'batch_size': 64,
    'epochs': 100,
    'learning_rate': 0.001,
    'weight_decay': 1e-4,
    'patience': 15,
    'vol_target': 0.15,
    'transaction_cost_bps': 5.0,
    'rebalance_days': 21,
    'max_leverage': 3.0,
    'train_years': 4,
    'val_months': 6,
    'test_months': 6,
    'device': 'cuda' if torch.cuda.is_available() else 'cpu',
    'seed': 42,
}

torch.manual_seed(CONFIG['seed'])
np.random.seed(CONFIG['seed'])

# =============================================================================
# DATA LOADING
# =============================================================================

def download_data():
    """Download ETF data from Yahoo Finance."""
    tickers = [t for ac in ASSET_CLASSES.values() for t in ac.keys()]
    print(f"Downloading {len(tickers)} ETFs...")
    
    data = yf.download(tickers, start=CONFIG['start_date'], end=CONFIG['end_date'], progress=True)
    
    all_data = []
    for ticker in tickers:
        try:
            df = data.xs(ticker, axis=1, level=1).copy() if len(tickers) > 1 else data.copy()
            df = df.reset_index()
            df.columns = [c.lower().replace(' ', '_') for c in df.columns]
            df['ticker'] = ticker
            
            for ac, ac_tickers in ASSET_CLASSES.items():
                if ticker in ac_tickers:
                    df['asset_class'] = ac
                    break
            
            if len(df.dropna()) >= 500:
                all_data.append(df[['date', 'ticker', 'asset_class', 'open', 'high', 'low', 'close', 'volume']])
        except:
            continue
    
    result = pd.concat(all_data, ignore_index=True)
    result = result.set_index(['date', 'ticker']).sort_index()
    result = result.groupby(level='ticker').ffill()
    
    print(f"Loaded {result.index.get_level_values('ticker').nunique()} ETFs")
    return result


def synthetic_data(start='2014-01-01', end='2024-01-01', seed=42):
    """Build deterministic OHLCV data for an offline pipeline smoke test.

    The simulated returns include mild autocorrelation so the training path has
    a learnable pattern. They are not market observations or performance proof.
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start=start, end=end)
    frames = []
    tickers = [ticker for group in ASSET_CLASSES.values() for ticker in group]

    for idx, ticker in enumerate(tickers):
        innovations = rng.normal(0.0002, 0.012 + 0.0004 * (idx % 5), len(dates))
        returns = np.zeros(len(dates))
        for i in range(1, len(dates)):
            returns[i] = 0.12 * returns[i - 1] + innovations[i]
        close = 100.0 * np.cumprod(1.0 + returns)
        overnight = rng.normal(0.0, 0.0015, len(dates))
        open_ = close * (1.0 + overnight)
        spread = np.abs(rng.normal(0.004, 0.001, len(dates)))
        high = np.maximum(open_, close) * (1.0 + spread)
        low = np.minimum(open_, close) * (1.0 - spread)
        volume = rng.integers(500_000, 5_000_000, len(dates))
        asset_class = next(
            name for name, members in ASSET_CLASSES.items() if ticker in members
        )
        frames.append(pd.DataFrame({
            'date': dates,
            'ticker': ticker,
            'asset_class': asset_class,
            'open': open_,
            'high': high,
            'low': low,
            'close': close,
            'volume': volume,
        }))

    return pd.concat(frames, ignore_index=True).set_index(
        ['date', 'ticker']
    ).sort_index()

# =============================================================================
# FEATURE ENGINEERING
# =============================================================================

def compute_features(data):
    """Compute volatility-scaled features."""
    print("Computing volatility-scaled features...")
    df = data.copy()
    grouped = df.groupby(level='ticker')
    
    df['return'] = grouped['close'].pct_change()
    
    # Volatility at different scales
    for window in [5, 21, 63, 126]:
        df[f'vol_{window}d'] = grouped['return'].transform(
            lambda x: x.rolling(window, min_periods=5).std() * np.sqrt(252))
    
    # Vol-scaled returns (main features)
    for period in [1, 5, 21, 63, 126, 252]:
        raw_ret = grouped['close'].pct_change(period)
        vol = df['vol_21d'] if period <= 21 else df['vol_63d']
        df[f'vol_ret_{period}d'] = (raw_ret / (vol + 1e-8)).clip(-5, 5)
    
    # MACD features
    for fast, slow in [(8, 24), (16, 48), (32, 96)]:
        ema_fast = grouped['close'].transform(lambda x: x.ewm(span=fast).mean())
        ema_slow = grouped['close'].transform(lambda x: x.ewm(span=slow).mean())
        df[f'macd_{fast}_{slow}'] = ((ema_fast - ema_slow) / (ema_slow + 1e-8) / (df['vol_21d'] + 1e-8)).clip(-5, 5)
    
    # Breakout signals
    for window in [20, 50]:
        high = grouped['high'].transform(lambda x: x.rolling(window).max())
        low = grouped['low'].transform(lambda x: x.rolling(window).min())
        df[f'breakout_{window}d'] = (df['close'] - low) / (high - low + 1e-8)
    
    # Price vs MA
    for window in [21, 50, 200]:
        ma = grouped['close'].transform(lambda x: x.rolling(window).mean())
        df[f'price_ma_{window}'] = ((df['close'] / ma - 1) / (df['vol_21d'] + 1e-8)).clip(-5, 5)
    
    feature_cols = ['vol_ret_1d', 'vol_ret_5d', 'vol_ret_21d', 'vol_ret_63d', 'vol_ret_126d', 'vol_ret_252d',
                    'macd_8_24', 'macd_16_48', 'macd_32_96', 'breakout_20d', 'breakout_50d',
                    'price_ma_21', 'price_ma_50', 'price_ma_200']
    
    print(f"Computed {len(feature_cols)} features")
    return df, feature_cols

# =============================================================================
# SEQUENCE PREPARATION
# =============================================================================

def prepare_sequences(data, feature_cols, asset_class, seq_length=63):
    """Prepare sequences for a single asset class."""
    ac_tickers = list(ASSET_CLASSES[asset_class].keys())
    sequences, labels, meta = [], [], []
    
    for ticker in ac_tickers:
        try:
            ticker_data = data.xs(ticker, level='ticker').sort_index()
        except KeyError:
            continue
        
        if len(ticker_data) < seq_length + 5:
            continue
        
        features = ticker_data[feature_cols].values
        returns = ticker_data['close'].pct_change().shift(-1).values
        vol = ticker_data['vol_21d'].values
        
        for i in range(seq_length, len(ticker_data) - 1):
            seq = features[i-seq_length:i]
            if np.isnan(seq).any() or np.isnan(returns[i]) or np.isnan(vol[i]):
                continue
            sequences.append(np.nan_to_num(np.clip(seq, -5, 5), 0))
            labels.append(returns[i])
            # The label is the return from i to i+1, so the realized P&L date is
            # i+1. Keeping meta at i would apply the signal one day too early.
            meta.append((ticker_data.index[i + 1], ticker, vol[i]))
    
    if not sequences:
        return None, None, None
    
    return np.array(sequences, dtype=np.float32), np.array(labels, dtype=np.float32).reshape(-1, 1), meta

# =============================================================================
# MODEL
# =============================================================================

class SharpeLoss(nn.Module):
    def __init__(self, tc_bps=5.0):
        super().__init__()
        self.tc = tc_bps / 10000
    
    def forward(self, positions, returns):
        positions, returns = positions.squeeze(), returns.squeeze()
        pnl = positions * returns
        sharpe = pnl.mean() / (pnl.std() + 1e-8) * np.sqrt(252)
        turnover = torch.abs(positions[1:] - positions[:-1]).mean() if len(positions) > 1 else 0
        return -sharpe + turnover * self.tc * 252


class DMN(nn.Module):
    def __init__(self, n_features, hidden_size=32, dropout=0.3):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden_size, batch_first=True)
        self.head = nn.Sequential(
            nn.Linear(hidden_size, hidden_size), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden_size, 1), nn.Tanh())
    
    def forward(self, x):
        _, (h, _) = self.lstm(x)
        return self.head(h[-1])

# =============================================================================
# TRAINING
# =============================================================================

def train_model(train_seq, train_labels, val_seq, val_labels):
    """Train model for one asset class."""
    device = torch.device(CONFIG['device'])
    model = DMN(train_seq.shape[2], CONFIG['hidden_size'], CONFIG['dropout']).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=CONFIG['learning_rate'], weight_decay=CONFIG['weight_decay'])
    criterion = SharpeLoss(CONFIG['transaction_cost_bps'])
    
    X_train = torch.FloatTensor(train_seq).to(device)
    y_train = torch.FloatTensor(train_labels).to(device)
    X_val = torch.FloatTensor(val_seq).to(device)
    y_val = torch.FloatTensor(val_labels).to(device)
    
    loader = DataLoader(TensorDataset(X_train, y_train), batch_size=CONFIG['batch_size'], shuffle=True, drop_last=True)
    
    best_sharpe, best_model, patience = -np.inf, None, 0
    
    for epoch in range(CONFIG['epochs']):
        model.train()
        for X, y in loader:
            loss = criterion(model(X), y)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        
        model.eval()
        with torch.no_grad():
            val_pnl = model(X_val).squeeze() * y_val.squeeze()
            val_sharpe = (val_pnl.mean() / (val_pnl.std() + 1e-8) * np.sqrt(252)).item()
        
        if val_sharpe > best_sharpe:
            best_sharpe = val_sharpe
            best_model = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= CONFIG['patience']:
                break
    
    if best_model:
        model.load_state_dict(best_model)
    return model.to(device), best_sharpe

# =============================================================================
# BACKTESTING
# =============================================================================

def backtest(data, models, test_data_by_class):
    """Backtest with vol scaling after network output."""
    signals = []
    
    for ac, (test_seq, test_meta) in test_data_by_class.items():
        if test_seq is None or ac not in models:
            continue
        
        model = models[ac]
        model.eval()
        X = torch.FloatTensor(test_seq).to(CONFIG['device'])
        
        with torch.no_grad():
            raw_signals = model(X).cpu().numpy().flatten()
        
        for i, (date, ticker, vol) in enumerate(test_meta):
            vol_scalar = np.clip(CONFIG['vol_target'] / vol, 0.2, 3.0) if vol > 0.01 else 1.0
            signals.append({'date': date, 'ticker': ticker, 'position': raw_signals[i] * vol_scalar})
    
    if not signals:
        return None, {}
    
    df = pd.DataFrame(signals)
    returns_dict = {t: data.xs(t, level='ticker')['return'].to_dict() 
                    for t in df['ticker'].unique() if t in data.index.get_level_values('ticker')}
    
    test_dates = sorted(df['date'].unique())
    rebal_dates = test_dates[::CONFIG['rebalance_days']]
    
    daily_returns, weights, previous_weights = [], {}, {}
    for date in test_dates:
        transaction_cost = 0.0
        if date in rebal_dates:
            day_df = df[df['date'] == date]
            new_weights = {r['ticker']: r['position'] for _, r in day_df.iterrows()}
            weights = new_weights
            leverage = sum(abs(w) for w in weights.values())
            if leverage > CONFIG['max_leverage']:
                weights = {k: v * CONFIG['max_leverage'] / leverage for k, v in weights.items()}
            turnover_names = set(previous_weights) | set(weights)
            turnover = sum(
                abs(weights.get(ticker, 0.0) - previous_weights.get(ticker, 0.0))
                for ticker in turnover_names
            )
            transaction_cost = turnover * CONFIG['transaction_cost_bps'] / 10000.0
            previous_weights = weights.copy()
        
        pnl = sum(w * returns_dict.get(t, {}).get(date, 0) for t, w in weights.items() 
                  if not np.isnan(returns_dict.get(t, {}).get(date, 0)))
        daily_returns.append({
            'date': date,
            'return': pnl - transaction_cost,
            'transaction_cost': transaction_cost,
        })
    
    rets = pd.DataFrame(daily_returns).set_index('date')['return'].dropna()
    if len(rets) < 10:
        return None, {}
    
    total = (1 + rets).prod() - 1
    ann_ret = (1 + total) ** (252 / len(rets)) - 1
    ann_vol = rets.std() * np.sqrt(252)
    cum = (1 + rets).cumprod()
    
    return pd.DataFrame(daily_returns).set_index('date'), {
        'CAGR%': ann_ret * 100, 'Sharpe': ann_ret / ann_vol if ann_vol > 0.01 else 0,
        'Vol%': ann_vol * 100, 'MaxDD%': ((cum - cum.expanding().max()) / cum.expanding().max()).min() * 100}

# =============================================================================
# MAIN
# =============================================================================

def run_dmn(data=None, offline=False, output_dir='results', asset_classes=None):
    """Run full DMN training and walk-forward backtest."""
    torch.manual_seed(CONFIG['seed'])
    np.random.seed(CONFIG['seed'])
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    asset_classes = asset_classes or list(ASSET_CLASSES)
    print("="*60)
    print("DEEP MOMENTUM NETWORK")
    print("="*60)
    
    # Load data
    if data is None:
        data = synthetic_data(
            CONFIG['start_date'], CONFIG['end_date'], CONFIG['seed']
        ) if offline else download_data()
    data, feature_cols = compute_features(data)
    data['return'] = data.groupby(level='ticker')['close'].pct_change()
    
    # Create walk-forward splits
    dates = data.index.get_level_values('date').unique().sort_values()
    splits = []
    train_end = dates[0] + pd.DateOffset(years=CONFIG['train_years'])
    
    while True:
        val_end = train_end + pd.DateOffset(months=CONFIG['val_months'])
        test_end = val_end + pd.DateOffset(months=CONFIG['test_months'])
        if test_end > dates.max():
            break
        
        train = dates[dates < train_end]
        val = dates[(dates >= train_end) & (dates < val_end)]
        test = dates[(dates >= val_end) & (dates < test_end)]
        
        if len(train) > 500 and len(val) > 50 and len(test) > 50:
            splits.append((train, val, test))
        train_end = val_end
    
    print(f"Prepared {len(splits)} walk-forward folds")
    
    # Train and test
    all_results, all_returns = [], []
    
    for fold, (train_dates, val_dates, test_dates) in enumerate(splits):
        print(f"\nFold {fold}: {test_dates[0].date()} to {test_dates[-1].date()}")
        
        train_data = data[data.index.get_level_values('date').isin(train_dates)]
        val_data = data[data.index.get_level_values('date').isin(val_dates)]
        test_data = data[data.index.get_level_values('date').isin(test_dates)]
        
        models, test_by_class = {}, {}
        for ac in asset_classes:
            train_seq, train_lbl, _ = prepare_sequences(train_data, feature_cols, ac)
            val_seq, val_lbl, _ = prepare_sequences(val_data, feature_cols, ac)
            test_seq, _, test_meta = prepare_sequences(test_data, feature_cols, ac)
            
            if train_seq is None or len(train_seq) < 100 or val_seq is None:
                test_by_class[ac] = (None, None)
                continue
            
            model, val_sharpe = train_model(train_seq, train_lbl, val_seq, val_lbl)
            models[ac] = model
            test_by_class[ac] = (test_seq, test_meta)
            print(f"  {ac}: val_sharpe={val_sharpe:.2f}")
        
        returns_df, metrics = backtest(data, models, test_by_class)
        if metrics:
            metrics['Fold'] = fold
            all_results.append(metrics)
            all_returns.append(returns_df)
            print(f"  CAGR: {metrics['CAGR%']:+.1f}% | Sharpe: {metrics['Sharpe']:.2f}")
    
    # Summary
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    df = pd.DataFrame(all_results)
    if df.empty:
        raise RuntimeError('No walk-forward folds produced results')
    print(f"Avg Sharpe: {df['Sharpe'].mean():.2f} | Avg CAGR: {df['CAGR%'].mean():.1f}%")
    print(f"Profitable: {(df['CAGR%'] > 0).sum()}/{len(df)} folds")
    df.to_csv(output_dir / 'fold_metrics.csv', index=False)
    
    # Plot equity curve
    if all_returns:
        combined = pd.concat(all_returns)
        combined = combined[~combined.index.duplicated(keep='first')]
        cum = (1 + combined['return']).cumprod()
        
        plt.figure(figsize=(12, 5))
        plt.plot(cum.index, cum.values, linewidth=1.5)
        plt.axhline(y=1, color='black', linestyle='--', alpha=0.5)
        plt.fill_between(cum.index, 1, cum.values, where=cum.values >= 1, alpha=0.3, color='green')
        plt.title('Deep Momentum Network - Equity Curve')
        plt.ylabel('Cumulative Return')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'equity_curve.png', dpi=150)
        plt.close()
        combined.to_csv(output_dir / 'daily_returns.csv')

    summary = {
        'data_mode': 'synthetic' if offline else 'market',
        'seed': CONFIG['seed'] if offline else None,
        'folds': int(len(df)),
        'profitable_folds': int((df['CAGR%'] > 0).sum()),
        'mean_cagr_pct': float(df['CAGR%'].mean()),
        'mean_sharpe': float(df['Sharpe'].mean()),
        'mean_vol_pct': float(df['Vol%'].mean()),
        'worst_fold_max_drawdown_pct': float(df['MaxDD%'].min()),
        'transaction_cost_bps': float(CONFIG['transaction_cost_bps']),
        'asset_classes': asset_classes,
        'claim_limit': (
            'Synthetic execution evidence only; no live or historical alpha claim.'
            if offline else 'Market-data research run; requires independent validation.'
        ),
    }
    (output_dir / 'summary.json').write_text(
        json.dumps(summary, indent=2), encoding='utf-8'
    )
    
    return all_results, all_returns


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Deep Momentum Network')
    parser.add_argument('--offline', action='store_true', help='Use deterministic synthetic data')
    parser.add_argument('--quick', action='store_true', help='Use a compact deterministic smoke-test configuration')
    parser.add_argument('--output-dir', default='results')
    args = parser.parse_args()

    selected_classes = None
    if args.quick:
        CONFIG.update({
            'start_date': '2016-01-01',
            'end_date': '2024-01-01',
            'sequence_length': 21,
            'hidden_size': 8,
            'dropout': 0.1,
            'batch_size': 128,
            'epochs': 4,
            'patience': 2,
            'train_years': 3,
            'val_months': 6,
            'test_months': 6,
        })
        selected_classes = ['equity']

    results, returns = run_dmn(
        offline=args.offline,
        output_dir=args.output_dir,
        asset_classes=selected_classes,
    )
