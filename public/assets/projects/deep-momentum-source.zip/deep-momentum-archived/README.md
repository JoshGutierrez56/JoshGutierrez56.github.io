# Deep Momentum Network

A PyTorch implementation of the Deep Momentum Network architecture described by Lim, Zohren, and Roberts (2019), with volatility-scaled features, LSTM position signals, walk-forward evaluation, and turnover-based transaction costs.

## Verified result

The repository includes measured, machine-readable results in [`results/`](results/README.md). The deterministic quick run uses synthetic equity ETF-like OHLCV data:

- 9 walk-forward folds
- 7 profitable folds
- Mean fold CAGR: 45.76%
- Mean fold Sharpe: 2.801
- Worst fold maximum drawdown: -8.19%

These large and unstable values are a consequence of the small synthetic example. They are not a 2010-2024 historical backtest and not evidence of investable alpha. The previous hard-coded benchmark claims have been removed.

## Reproduce

```bash
python -m pip install -r requirements.txt
python dmn.py --offline --quick --output-dir results
python benchmark.py --metrics results/fold_metrics.csv --output results/fold_metrics.png
python -m pytest -q
```

For live public-data research, omit `--offline` and `--quick`. Network requests use normal certificate verification.

## Methodology

1. Build volatility-scaled returns and technical features.
2. Train an LSTM separately by configured asset class.
3. Produce bounded positions through a `tanh` output.
4. Scale positions to the volatility target.
5. Align each signal with the following day's return.
6. Deduct realized turnover costs.
7. Record every fold rather than reporting hard-coded metrics.

## Files

- `dmn.py` - data generation/download, features, network, and walk-forward run
- `benchmark.py` - visualization of the recorded fold CSV
- `tests/` - determinism, alignment, and evidence-validation tests
- `results/` - committed evidence and assumptions

Reference: Lim, B., Zohren, S., and Roberts, S. (2019), “Enhancing Time Series Momentum Strategies Using Deep Neural Networks.”

This project is educational research, not investment advice.
