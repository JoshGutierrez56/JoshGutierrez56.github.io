"""Visualize metrics produced by an actual DMN run.

This module intentionally contains no hard-coded performance numbers. Run
``dmn.py`` first, then point this script at its fold-level metrics file.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def plot_fold_results(metrics_path: str, output_path: str) -> pd.DataFrame:
    metrics_file = Path(metrics_path)
    if not metrics_file.exists():
        raise FileNotFoundError(
            f"{metrics_file} does not exist. Run `python dmn.py --offline --quick` first."
        )

    df = pd.read_csv(metrics_file)
    required = {"Fold", "CAGR%", "Sharpe", "Vol%", "MaxDD%"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"metrics file is missing columns: {sorted(missing)}")

    print("=" * 60)
    print("DMN WALK-FORWARD FOLD RESULTS")
    print("=" * 60)
    print(df.sort_values("Fold").round(3).to_string(index=False))

    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    plots = [
        ("CAGR%", "CAGR (%)", "#2E86AB"),
        ("Sharpe", "Sharpe ratio", "#3B7A57"),
        ("Vol%", "Annualized volatility (%)", "#A23B72"),
        ("MaxDD%", "Maximum drawdown (%)", "#C73E1D"),
    ]
    for ax, (column, title, color) in zip(axes.flat, plots):
        ax.bar(df["Fold"].astype(str), df[column], color=color, edgecolor="black")
        ax.axhline(0, color="black", linewidth=0.8)
        ax.set_title(title, fontweight="bold")
        ax.set_xlabel("Walk-forward fold")
        ax.grid(axis="y", alpha=0.25)

    fig.suptitle("Deep Momentum Network — Recorded Fold Results", fontweight="bold")
    fig.tight_layout()
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=150, facecolor="white")
    plt.close(fig)
    print(f"Saved {output}")
    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Plot recorded DMN fold metrics")
    parser.add_argument("--metrics", default="results/fold_metrics.csv")
    parser.add_argument("--output", default="results/fold_metrics.png")
    args = parser.parse_args()
    plot_fold_results(args.metrics, args.output)
