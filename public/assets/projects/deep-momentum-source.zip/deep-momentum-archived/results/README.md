# Verified results

Reproduce the committed evidence with:

```bash
python dmn.py --offline --quick --output-dir results
python benchmark.py --metrics results/fold_metrics.csv --output results/fold_metrics.png
```

The quick run trains an equity-only LSTM across nine walk-forward folds using deterministic synthetic OHLCV data and 5 bps transaction costs.

Recorded result:

- Profitable folds: 7 of 9
- Mean fold CAGR: 45.76%
- Mean fold Sharpe: 2.801
- Mean fold volatility: 10.16%
- Worst fold maximum drawdown: -8.19%

The unusually large and variable fold returns are a property of the small synthetic training example. They must not be read as a real-market performance claim.

Artifacts:

- `summary.json` - run assumptions and aggregate metrics
- `fold_metrics.csv` - measured metrics for every fold
- `daily_returns.csv` - out-of-sample synthetic returns
- `equity_curve.png` - cumulative synthetic return
- `fold_metrics.png` - chart generated from the recorded CSV, with no hard-coded benchmark values
